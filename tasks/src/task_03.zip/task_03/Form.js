import { useForm } from "react-hook-form"

const Form = () => {
    const {
        register,
        handleSubmit,
        formState: {errors},
        reset
    } = useForm()

    const onSubmit = (data) => console.log(data)

    const isFirstLetterUpper = (v) => {
        if (!v)
            return "This field is required"

        if (v[0] !== v[0].toUpperCase())
            return "First letter must be uppercase"
        return true
    }

    const passwordValidator = (password) => {
        const special_chars = "!@#$%^&*()_-".split('')
        if (!special_chars.some(v => password.includes(v))) {
            return "Must contain at least one special character ( !@#$%^&*()_- )"
        }
        if (password === password.toLowerCase()) {
            return "Must contain at least one uppercase letter"
        }
        if (!/\d/.test(password)) {
            return "Must contain at least one number"
        }
    }

    const handleClear = () => {
        reset({
            first_name: "",
            last_name: "",
            email: "",
            password: "",
            gender: "",
            marketing_checkbox: false,
            tos_checkbox: false,
          })
    }

    return (
        <form className="form-horizontal container mt-5" onSubmit={handleSubmit(onSubmit)}>
            <div className="form-group d-flex flex-column w-25">
                <label className="text-secondary">First Name</label>
                <input className="form-control" {...register("first_name", {
                    required: "First name is required",
                    pattern: {
                        value: /^[a-z]+$/i,
                        message: "Only letters are allowed"
                    },
                    validate: {
                        required: isFirstLetterUpper,
                    }
                })}/>
                <p style={{ color: "red" }}>&nbsp;{errors.first_name && <>* {errors.first_name.message}</>}</p>
            </div>
            <div className="form-group d-flex flex-column w-25">
                <label className="text-secondary">Last Name</label>
                <input className="form-control" {...register("last_name", {
                    required: "Last name is required",
                    pattern: {
                        value: /^[a-z]+$/i,
                        message: "Only letters are allowed"
                    },
                    validate: {
                        required: isFirstLetterUpper,
                    }
                })}/>
                <p style={{ color: "red" }}>&nbsp;{errors.last_name && <>* {errors.last_name.message}</>}</p>
            </div>
            <div className="form-group d-flex flex-column w-25">
                <label className="text-secondary">Email</label>
                <input className="form-control" {...register("email", {
                    required: "Email required",
                    pattern: {
                        value: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
                        message: "Wrong email parsed"
                    }
                })}/>
                <p style={{ color: "red" }}>&nbsp;{errors.email && <>* {errors.email.message}</>}</p>
            </div>
            <div className="form-group d-flex flex-column w-25">
                <label className="text-secondary">Password</label>
                <input className="form-control" type="password" {...register("password", {
                    required: "Password required",
                    validate: {
                        required: passwordValidator,
                    }
                })}/>
                <p style={{ color: "red" }}>&nbsp;{errors.password && <>* {errors.password.message}</>}</p>
            </div>
            <div className="form-group d-flex flex-column w-25">
                <label className="text-secondary">Gender</label>
                <select className="form-control" {...register("gender", {
                    required: "select one option",
                })}>
                    <option value=""></option>
                    <option value="male">MALE</option>
                    <option value="female">FEMALE</option>
                </select>
                <p style={{ color: "red" }}>&nbsp;{errors.gender && <>* {errors.gender.message}</>}</p>
            </div>
            <div className="form-group d-flex flex-row w-25 form-check">
                <label className="text-secondary">
                    <input type="checkbox" {...register("marketing_checkbox")}/>
                &nbsp;Marketing</label>
            </div>
            <div className="form-group d-flex flex-column w-25 form-check">
                <div className="d-flex flex-row">
                    <label className="text-secondary">
                        <input type="checkbox" {...register("tos_checkbox", {
                            required: "This checkbox is required",
                        })}/>
                    &nbsp;Terms of service</label>
                </div>
                <p style={{ color: "red" }}>&nbsp;{errors.tos_checkbox && <>* {errors.tos_checkbox.message}</>}</p>
            </div>
            <div className="form-group d-flex flex-row justify-content-between w-25">
                <input type="button" className="btn btn-secondary" value="Clear" onClick={handleClear}/>
                <input type="submit" className="btn btn-primary" value="Submit"/>
            </div>
        </form>
    )
}

export default Form